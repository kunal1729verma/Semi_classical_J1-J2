data = [T, J2byJ1, avg_Energy, stderr_Energy, avg_total_magnet, stderr_total_magnet, avg_Mππ, stderr_Mππ, avg_M0π, stderr_M0π, avg_Mπ0, stderr_Mπ0, avg_N_dimer, stderr_N_dimer]
